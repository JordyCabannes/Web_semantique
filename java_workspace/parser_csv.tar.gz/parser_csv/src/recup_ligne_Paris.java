import java.io.* ;
import java.util.*;


public class recup_ligne_Paris 
{
	private String titre;
	private String realisateur;
	private Date deb_evt;
	private Date fin_evt ;
	private String cadre ;
	private String lieu ; 
	private String adresse;
	private int arrondissement ;
	private String adresse_Complete; 
	private float coordX;
	private float coordY; 
	
	
	public recup_ligne_Paris(String titre , String realisateut,Date deb_evt, Date fin_evt,String cadre,String lieu,String adresse,int arrond, String addr_compl)
	{
		this.titre=titre; 
		this.realisateur= realisateut;
		this.deb_evt =deb_evt;
		this.fin_evt = fin_evt; 
		this.cadre=cadre;
		this.lieu=lieu;
		this.adresse=adresse;
		this.arrondissement=arrond;
		this.adresse_Complete =addr_compl;
		
		
	}
	
	public void addCoord(float x ,float  y )
	{
		this.coordX =coordX;
		this.coordY=coordY;
	}
	


}
